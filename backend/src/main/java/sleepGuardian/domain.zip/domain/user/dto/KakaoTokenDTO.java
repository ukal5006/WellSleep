package sleepGuardian.domain.user.dto;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor

public class KakaoTokenDTO {
    private String kakaoToken;
}
