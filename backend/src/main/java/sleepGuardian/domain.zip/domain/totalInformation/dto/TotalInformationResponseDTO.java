package sleepGuardian.domain.totalInformation.dto;

public class TotalInformationResponseDTO {
}
