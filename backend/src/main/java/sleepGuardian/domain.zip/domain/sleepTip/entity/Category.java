package sleepGuardian.domain.sleepTip.entity;

public enum Category {
    팁,음식
}
